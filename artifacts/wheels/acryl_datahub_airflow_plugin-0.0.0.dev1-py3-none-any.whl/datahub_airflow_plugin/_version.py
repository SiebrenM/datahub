# Published at https://pypi.org/project/acryl-datahub-airflow-plugin/.
__package_name__ = "acryl-datahub-airflow-plugin"
__version__ = "0.0.0.dev1"
