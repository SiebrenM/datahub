# Datahub Dagster Plugin

See the [DataHub Dagster docs](https://datahubproject.io/docs/lineage/dagster/) for details.
